package dev.fpsmax;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Guardian;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Lossless occlusion culling for entities.
 *
 * An entity is skipped only if EVERY test ray from the camera to its (slightly enlarged)
 * bounding box is blocked by a fully opaque, full-size block. Glass, leaves, water, stairs,
 * slabs, doors etc. never block, so nothing that could be seen is ever hidden.
 * Results are cached per entity and refreshed every few frames.
 */
public final class OcclusionCuller {

    public static volatile boolean enabled = true;
    public static long checked = 0;
    public static long culled = 0;

    private static final double MIN_DIST_SQ = 4.0 * 4.0;
    private static final double MAX_DIST_SQ = 96.0 * 96.0;
    private static final double MAX_CAM_OFFSET_SQ = 16.0 * 16.0; // ignore shadow-pass / freecam cameras
    private static final double MAX_BOX_SIZE = 6.0;
    private static final double MARGIN = 0.5;
    private static final long RECHECK_VISIBLE_NS = 100_000_000L; // 100 ms
    private static final long RECHECK_HIDDEN_NS = 50_000_000L;  // 50 ms
    private static final int MAX_STEPS = 192;

    private static final class State {
        long nextCheck;
        boolean hidden;
    }

    private static final Int2ObjectOpenHashMap<State> CACHE = new Int2ObjectOpenHashMap<>();
    private static final BlockPos.MutableBlockPos POS = new BlockPos.MutableBlockPos();
    private static ClientLevel lastLevel;

    private OcclusionCuller() {}

    public static boolean isHidden(Entity entity, double camX, double camY, double camZ) {
        if (!enabled) return false;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null || player.isSpectator()) return false;
        if (entity == mc.getCameraEntity() || !canCull(entity)) return false;

        // Only trust the real player camera (not shader shadow passes etc.)
        double ex = camX - player.getEyePosition().x;
        double ey = camY - player.getEyePosition().y;
        double ez = camZ - player.getEyePosition().z;
        if (ex * ex + ey * ey + ez * ez > MAX_CAM_OFFSET_SQ) return false;

        AABB box = entity.getBoundingBox();
        double dx = (box.minX + box.maxX) * 0.5 - camX;
        double dy = (box.minY + box.maxY) * 0.5 - camY;
        double dz = (box.minZ + box.maxZ) * 0.5 - camZ;
        double distSq = dx * dx + dy * dy + dz * dz;
        if (distSq < MIN_DIST_SQ || distSq > MAX_DIST_SQ) return false;

        if (level != lastLevel) {
            CACHE.clear();
            lastLevel = level;
        }

        int id = entity.getId();
        State st = CACHE.get(id);
        if (st == null) {
            if (CACHE.size() > 4096) CACHE.clear();
            st = new State();
            CACHE.put(id, st);
        }

        checked++;
        long now = System.nanoTime();
        if (now >= st.nextCheck) {
            st.hidden = computeHidden(level, box, camX, camY, camZ);
            long base = st.hidden ? RECHECK_HIDDEN_NS : RECHECK_VISIBLE_NS;
            st.nextCheck = now + base + (id & 7) * 3_000_000L; // jitter spreads the work over frames
        }
        if (st.hidden) culled++;
        return st.hidden;
    }

    /** Only things whose visuals match their hitbox and that have no see-through extras. */
    private static boolean canCull(Entity e) {
        if (e instanceof Player) return false;                       // name tags / gameplay
        if (!(e instanceof LivingEntity || e instanceof ItemEntity || e instanceof ItemFrame)) return false;
        if (e instanceof Guardian) return false;                      // beam is drawn by the guardian
        if (e.isCurrentlyGlowing() || e.isCustomNameVisible()) return false;
        if (e.isPassenger() || e.isVehicle()) return false;
        if (e instanceof Mob mob && mob.isLeashed()) return false;   // leash is drawn by the mob
        AABB b = e.getBoundingBox();
        return b.getXsize() <= MAX_BOX_SIZE && b.getYsize() <= MAX_BOX_SIZE && b.getZsize() <= MAX_BOX_SIZE;
    }

    private static boolean computeHidden(ClientLevel level, AABB b, double camX, double camY, double camZ) {
        // Camera inside an opaque block (e.g. clipped camera): never cull.
        if (isOpaque(level, POS.set(Mth.floor(camX), Mth.floor(camY), Mth.floor(camZ)))) return false;

        double mx = (b.minX + b.maxX) * 0.5, my = (b.minY + b.maxY) * 0.5, mz = (b.minZ + b.maxZ) * 0.5;
        if (!blocked(level, camX, camY, camZ, mx, my, mz)) return false;

        double[] xs = { b.minX - MARGIN, b.maxX + MARGIN };
        double[] ys = { b.minY - MARGIN, b.maxY + MARGIN };
        double[] zs = { b.minZ - MARGIN, b.maxZ + MARGIN };
        for (double px : xs) {
            for (double py : ys) {
                for (double pz : zs) {
                    if (!blocked(level, camX, camY, camZ, px, py, pz)) return false;
                }
            }
        }
        return true;
    }

    /** Voxel traversal (Amanatides–Woo). Returns true if an opaque block lies on the segment. */
    private static boolean blocked(ClientLevel level,
                                   double x0, double y0, double z0,
                                   double x1, double y1, double z1) {
        int x = Mth.floor(x0), y = Mth.floor(y0), z = Mth.floor(z0);
        final int endX = Mth.floor(x1), endY = Mth.floor(y1), endZ = Mth.floor(z1);
        if (x == endX && y == endY && z == endZ) return false;

        double dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        int sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
        double tdx = dx == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dx);
        double tdy = dy == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dy);
        double tdz = dz == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dz);
        double tmx = dx == 0 ? Double.POSITIVE_INFINITY : (dx > 0 ? (x + 1 - x0) : (x0 - x)) * tdx;
        double tmy = dy == 0 ? Double.POSITIVE_INFINITY : (dy > 0 ? (y + 1 - y0) : (y0 - y)) * tdy;
        double tmz = dz == 0 ? Double.POSITIVE_INFINITY : (dz > 0 ? (z + 1 - z0) : (z0 - z)) * tdz;

        for (int i = 0; i < MAX_STEPS; i++) {
            if (tmx < tmy && tmx < tmz) { x += sx; tmx += tdx; }
            else if (tmy < tmz)         { y += sy; tmy += tdy; }
            else                        { z += sz; tmz += tdz; }

            if (isOpaque(level, POS.set(x, y, z))) return true;
            if (x == endX && y == endY && z == endZ) return false;
        }
        return false; // be conservative: assume visible
    }

    private static boolean isOpaque(ClientLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.canOcclude() && s.isCollisionShapeFullBlock(level, pos);
    }
}
