package dev.fpsmax;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.network.chat.Component;

public class FpsMax implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("fpsmax")
                // /fpsmax — toggle on/off
                .executes(ctx -> {
                    OcclusionCuller.enabled = !OcclusionCuller.enabled;
                    ctx.getSource().sendFeedback(Component.literal(
                        "FPS Max: " + (OcclusionCuller.enabled ? "ON" : "OFF")));
                    return Command.SINGLE_SUCCESS;
                })
                // /fpsmax stats — how many entity draws were skipped since last call
                .then(ClientCommandManager.literal("stats").executes(ctx -> {
                    long checked = OcclusionCuller.checked;
                    long culled = OcclusionCuller.culled;
                    OcclusionCuller.checked = 0;
                    OcclusionCuller.culled = 0;
                    long pct = checked == 0 ? 0 : culled * 100 / checked;
                    ctx.getSource().sendFeedback(Component.literal(
                        "FPS Max: skipped " + culled + " of " + checked + " entity draws (" + pct + "%)"));
                    return Command.SINGLE_SUCCESS;
                }))));
    }
}
